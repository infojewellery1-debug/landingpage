# E-Learning-Website
E-Learning Website
Django Webapp for Students and Teachers to manage their School work.
Teachers can add subjects , topics and questions accordingly for students and grade the answers on the basis of the student responses.
Students can answer questions provided by the teachers and can check their grades once marked by the teacher.
One of the unique feature is, Automated Answer Checking which uses Machine Learning and Natural Language Processing to find similarity betweeb
the desired and given asnwer and then provide grades accordingly.
